import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { EmployeeserviceService } from './employeeservice.service';
import { FormsModule } from '@angular/forms';
import { OrderbyPipe } from './orderby.pipe'

@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    EmployeeListComponent,
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,EmployeeserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
